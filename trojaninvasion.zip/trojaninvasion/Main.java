package trojaninvasion;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        boolean spartansWon = true;

        int numberWavesTrojans = Integer.parseInt(scanner.nextLine());
        int[] spartanPlatesArray = Arrays.stream(scanner.nextLine().split("\\s+"))
                .mapToInt(Integer::parseInt).toArray();
        ArrayDeque<Integer> spartanPlatesQueue = createQueue(spartanPlatesArray);

        int[] trojansWarriorsArray = Arrays.stream(scanner.nextLine().split("\\s+"))
                .mapToInt(Integer::parseInt).toArray();
        ArrayDeque<Integer> trojanWavesWarriorsStack = createStack(trojansWarriorsArray);

        int counter = 1;
        while (counter <= numberWavesTrojans){
            if (counter % 3 == 0) {
                int newSpartanPlate = Integer.parseInt(scanner.nextLine());
                spartanPlatesQueue.add(newSpartanPlate);
            }

            while (!spartanPlatesQueue.isEmpty() && !trojanWavesWarriorsStack.isEmpty()) {
                fight(spartanPlatesQueue, trojanWavesWarriorsStack);
            }

            if (spartanPlatesQueue.isEmpty()) {
                spartansWon = false;
                break;
            }
                if(counter==numberWavesTrojans){
                    break;
                } else {
                    trojansWarriorsArray = Arrays.stream(scanner.nextLine().split("\\s+"))
                            .mapToInt(Integer::parseInt).toArray();
                    trojanWavesWarriorsStack = createStack(trojansWarriorsArray);
                }
                counter++;

        }

        if (spartansWon) {
            System.out.printf("The Spartans successfully repulsed the Trojan attack.%n");
            System.out.print("Plates left: ");
            printArrayDeck(spartanPlatesQueue);
        } else {
            System.out.printf("The Trojans successfully destroyed the Spartan defense.%n");
            System.out.print("Warriors left: ");
            printArrayDeck(trojanWavesWarriorsStack);

        }
    }

    private static ArrayDeque<Integer> createQueue(int[] array) {
        ArrayDeque<Integer> arrayDeque = new ArrayDeque<>();
        for (int value : array) {
            arrayDeque.add(value);
        }
        return arrayDeque;
    }

    private static ArrayDeque<Integer> createStack(int[] array) {
        ArrayDeque<Integer> arrayDeque = new ArrayDeque<>();
        for (int value : array) {
            arrayDeque.push(value);
        }
        return arrayDeque;
    }

    private static void fight(ArrayDeque<Integer> queue, ArrayDeque<Integer> stack) {
        int currentValue = 0;
        if (stack.peek() < queue.getFirst()) {
            currentValue = queue.getFirst() - stack.pop();
            queue.poll();
            queue.addFirst(currentValue);
        } else if (stack.peek() > queue.getFirst()) {
            currentValue = stack.peek() - queue.poll();
            stack.pop();
            stack.push(currentValue);
        } else {
            queue.poll();
            stack.pop();
        }
    }

    private static void printResult(ArrayDeque<Integer> queue) {
        if (queue.isEmpty()) {
            System.out.printf("The Trojans successfully destroyed the Spartan defense.%n");
            System.out.println("Warriors left: ");
        } else {
            System.out.printf("The Spartans successfully repulsed the Trojan attack.%n");
            System.out.println("Plates left: ");
        }
    }

    private static void printArrayDeck(ArrayDeque<Integer> arrayDeque) {
        while (1 < arrayDeque.size()) {
            System.out.print(arrayDeque.poll());
            System.out.print(", ");
        }
        System.out.printf("%d", arrayDeque.peek());
    }
}
