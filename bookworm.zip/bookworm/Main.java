package bookworm;

        import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String initial = scanner.nextLine();
        int numberRows = Integer.parseInt(scanner.nextLine());
        char[][] field = new char[numberRows][];

        for (int i = 0; i < numberRows; i++) {
            char[] current = scanner.nextLine().toCharArray();
            field[i] = current;
        }

        String input = scanner.nextLine();
        while (!input.equals("end")) {
            int[] positions = findPositionPlayer(field);
            int rowPosition = positions[0];
            int colPosition = positions[1];
            String command = input;
            int nextRow = -1;
            int nextCol = -1;
            switch (command) {
                case "up":
                    nextRow = rowPosition - 1;
                    nextCol = colPosition;
                    if (isInField(field, nextRow, nextCol)) {
                        char ch2 = field[nextRow][nextCol];
                        if (ch2 != '-') {
                            initial = buildTheInitial(initial, ch2);
                        }
                        move(field, rowPosition, colPosition, nextRow, nextCol);
                    } else {
                        initial = rebuildTheInitial(initial);
                    }
                    break;
                case "down":
                    nextRow = rowPosition + 1;
                    nextCol = colPosition;
                    if (isInField(field, nextRow, nextCol)) {
                        char ch3 = field[nextRow][nextCol];
                        if (ch3 != '-') {
                            initial = buildTheInitial(initial, ch3);
                        }
                        move(field, rowPosition, colPosition, nextRow, nextCol);
                    } else {
                        initial = rebuildTheInitial(initial);
                    }
                    break;
                case "left":
                    nextRow = rowPosition;
                    nextCol = colPosition - 1;
                    if (isInField(field, nextRow, nextCol)) {
                        char ch4 = field[nextRow][nextCol];
                        if (ch4 != '-') {
                            initial = buildTheInitial(initial, ch4);
                        }
                        move(field, rowPosition, colPosition, nextRow, nextCol);
                    } else {
                        initial = rebuildTheInitial(initial);
                    }
                    break;
                case "right":
                    nextRow = rowPosition;
                    nextCol = colPosition + 1;
                    if (isInField(field, nextRow, nextCol)) {
                        char ch5 = field[nextRow][nextCol];
                        if (ch5 != '-') {
                            initial = buildTheInitial(initial, ch5);
                        }
                        move(field, rowPosition, colPosition, nextRow, nextCol);
                    } else {
                        initial = rebuildTheInitial(initial);
                    }
                    break;
            }
            input = scanner.nextLine();
        }
        System.out.printf("%s%n", initial);
        printResult(field);
    }

    private static int[] findPositionPlayer(char[][] field) {
        int[] positions = new int[2];
        for (int row = 0; row < field.length; row++) {
            for (int col = 0; col < field[row].length; col++) {
                char current = field[row][col];
                if (current == 'P') {
                    positions[0] = row;
                    positions[1] = col;
                    break;
                }
            }
        }
        return positions;
    }

    private static boolean isInField(char[][] matrix, int row, int col) {
        if (0 <= row && row < matrix.length && 0 <= col && col < matrix.length) {
            return true;
        }
        return false;
    }

    private static char[][] move(char[][] matrix,
                                 int rowCurrent, int colCurrent,
                                 int nextRow, int nextCol) {
        matrix[nextRow][nextCol] = matrix[rowCurrent][colCurrent];
        matrix[rowCurrent][colCurrent] = '-';
        return matrix;
    }

    private static String buildTheInitial(String word, char letter) {
        return word += letter;
    }

    private static String rebuildTheInitial(String word) {
        String newWord = word.substring(0, word.length() - 1);
        return newWord;
    }

    private static void printResult(char[][] matrix) {
        for (char[] chars : matrix) {
            for (char c : chars) {
                System.out.print(c);
            }
            System.out.println();
        }
    }
}
