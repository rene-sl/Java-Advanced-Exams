package datingapp;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Scanner;

public class DatingApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] malesArray = Arrays.stream(scanner.nextLine().split("\\s+"))
                .mapToInt(Integer::parseInt).toArray();
        int[] femalesArray = Arrays.stream(scanner.nextLine().split("\\s+"))
                .mapToInt(Integer::parseInt).toArray();

        ArrayDeque<Integer> females = createQueue(femalesArray);
        ArrayDeque<Integer> males = createStack(malesArray);
        int count = 0;

        while (!(males.isEmpty() || females.isEmpty())) {

            if (areMatched(females.peek(), males.peek())) {
                females.poll();
                males.pop();
                count++;
            } else {
                if (checkValueForRestriction(females.peek())) {
                    females.poll();
                    females.poll();
                } else {
                    females.poll();
                }
                if (checkValueForRestriction(males.peek())) {
                    males.pop();
                    males.pop();
                }
                if (!females.isEmpty() || !males.isEmpty()) {
                    int currentMale = males.pop() - 2;
                    if (0 < currentMale)
                        males.push(currentMale);
                }
            }
        }

        System.out.printf("Matches: %d%n", count);
        if (males.isEmpty()) {
            System.out.printf("Males left: none%n");
        } else {
            System.out.printf("Males left:");
            for (int i = 0; i < males.size(); i++) {
                if (i < males.size() - 1) {
                    System.out.printf(" %d,", males.peek());
                } else {
                    System.out.printf(" %d%n", males.peek());
                }
            }
        }
        if (females.isEmpty()) {
            System.out.printf("Females left: none%n");
        } else {
            for (int i = 0; i < females.size(); i++) {
                if (i < females.size() - 1) {
                    System.out.printf(" %d,", females.peek());
                } else {
                    System.out.printf(" %d%n", females.peek());
                }
            }
        }
    }

    private static ArrayDeque<Integer> createStack(int[] array) {
        ArrayDeque<Integer> stack = new ArrayDeque<>();
        for (int i : array) {
            stack.push(i);
        }
        return stack;
    }

    private static ArrayDeque<Integer> createQueue(int[] array) {
        ArrayDeque<Integer> queue = new ArrayDeque<>();
        for (int i : array) {
            queue.offer(i);
        }
        return queue;
    }

    private static boolean areMatched (int value1, int value2){
        if (value1==value2){
            return true;
        } else {
            return false;
        }
    }

    public static boolean checkValueForRestriction( int value ){
        if (value%25 ==0){
            return true;
        }else {
            return false;
        }
    }
}
