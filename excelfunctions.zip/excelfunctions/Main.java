package excelfunctions;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int rows = Integer.parseInt(scanner.nextLine());
        String[][] data = createMatrixWithData(scanner, rows);
        String[] commands = scanner.nextLine().split("\\s+");
        String command = commands[0];
        String headerInfo = commands[1];
        String value = "";
        if (commands.length == 3) {
            value = commands[2];
        }
        String[][] newMatrixData = new String[rows - 1][];

        switch (command) {
            case "hide":
                hidePrint(data, headerInfo);
                break;
            case "sort":
                //sortPrint(data, headerInfo);
                break;
            case "filter":
                filterPrint(data, headerInfo, value);
                break;
            default:
                break;


        }

    }

    public static String[][] createMatrixWithData(Scanner scanner, int rows) {
        String[][] matrix = new String[rows][];
        for (int i = 0; i < matrix.length; i++) {
            String[] currentRow = scanner.nextLine().split(", ");
            matrix[i] = currentRow;
        }
        return matrix;
    }

    public static void hidePrint(String[][] data, String hideString) {
        int collum = -1;
        for (int row = 0; row < data.length; row++) {
            for (int col = 0; col < data[row].length; col++) {
                String current = data[row][col];
                if (current.equals(hideString) || col == collum) {
                    collum = col;
                    continue;
                }
                if (col == data[row].length - 1) {
                    System.out.printf("%s", current);
                } else {
                    System.out.printf("%s | ", current);
                }
            }
            System.out.println();
        }
    }

    /* private static void sortPrint(String[][] data, String headerInfo) {
         int collum = -1;
         for (int col = 0; col < data.length ; col++) {
             for (int row = 0; row < data[col].length ; row++) {
                 String current = data[col][row];
                 if(current.equals(headerInfo) || col == collum ){
                     collum = col;
                     continue;
                 }
                 if(col==data[row].length-1){
                     System.out.printf("%s%n", current);
                 } else {
                     System.out.printf("%s | %n", current);
                 }
             }

         }
     }
 */
    private static void filterPrint(String[][] data, String headerInfo, String value) {
        int collum = -1;
        for (int row = 0; row < data.length; row++) {
            for (int col = 0; col < data[row].length; col++) {
                String current = data[row][col];
                if (current.equals(headerInfo) || col == collum) {
                    collum = col;
                    break;
                }
            }
        }
        int roww = -1;
        for (int row = 0; row < data.length; row++) {
            String current = data[row][collum];
            if(current.equals(headerInfo)){
                roww = row;
                break;
            }
        }
        for (int col = 0; col < data[roww].length ; col++) {
            if(col==data[roww].length-1){
                System.out.printf("%s", data[roww][col]);
            } else {
                System.out.printf("%s | ", data[roww][col]);
            }
        }
        for (int row = 0; row < data.length; row++) {
            String current = data[row][collum];
            if(current.equals(value)){
                roww = row;
                break;
            }
        }
        System.out.println();
        for (int col = 0; col < data[roww].length ; col++) {
            if(col==data[roww].length-1){
                System.out.printf("%s", data[roww][col]);
            } else {
                System.out.printf("%s | ", data[roww][col]);
            }
        }
    }
}
