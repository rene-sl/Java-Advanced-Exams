package helensabduction;


        import java.util.Arrays;
        import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int energy = Integer.parseInt(scanner.nextLine());
        int numberRows = Integer.parseInt(scanner.nextLine());

        char[][] field = new char[numberRows][];
        for (int i = 0; i < field.length; i++) {
            field[i] = scanner.nextLine().toCharArray();
        }

        int [] parisCoordinates = givePositionsCoordinates('P',field);
        int currentRowParis = parisCoordinates[0];
        int currentColParis = parisCoordinates[1];

        int [] helenCoordinates = givePositionsCoordinates('H',field);
        int helenRow = helenCoordinates[0];
        int helenCol = helenCoordinates[1];

        while(0<energy && !(Arrays.equals(parisCoordinates, helenCoordinates))){
            String [] tokens = scanner.nextLine().split(" ");
            String command = tokens[0];
            int positionEnemyRow = Integer.parseInt(tokens[1]);
            int positionEnemyCol = Integer.parseInt(tokens[2]);
            markEnemyPositionInField(field,positionEnemyRow,positionEnemyCol);
            int[]enemyCoordinates=new int[2];
            enemyCoordinates[0] = positionEnemyRow;
            enemyCoordinates[1] = positionEnemyCol;


            int nextRowParis =-20;
            int nextColParis =-20;


            switch (command){
                case "up":
                    nextRowParis = currentRowParis - 1;
                    nextColParis = currentColParis;
                    if(isInField(nextRowParis, nextColParis, field)){
                        move(currentRowParis,currentColParis,nextRowParis,nextColParis,field);
                        parisCoordinates = givePositionsCoordinates('P',field);
                        currentRowParis=parisCoordinates[0];
                        currentColParis=parisCoordinates[1];
                        if(Arrays.equals(enemyCoordinates, parisCoordinates)){
                            energy= fight(energy);
                        } else {
                            energy = decreasesEnergyByMoving(energy);
                        }
                    }else{
                        energy = decreasesEnergyByMoving(energy);
                    }
                    break;
                case "down":
                    nextRowParis = currentRowParis + 1;
                    nextColParis = currentColParis;
                    if (isInField(nextRowParis, nextColParis, field)){
                        move(currentRowParis,currentColParis,nextRowParis,nextColParis,field);
                        parisCoordinates = givePositionsCoordinates('P',field);
                        currentRowParis=parisCoordinates[0];
                        currentColParis=parisCoordinates[1];
                    if(Arrays.equals(enemyCoordinates, parisCoordinates)){
                        energy= fight(energy);
                    } else {
                        energy = decreasesEnergyByMoving(energy);
                    }
            }else{
                        energy = decreasesEnergyByMoving(energy);
            }
                    break;
                case "left":
                    nextColParis = currentColParis - 1 ;
                    nextRowParis = currentRowParis;
                    if (isInField(nextRowParis, nextColParis, field)){
                        move(currentRowParis,currentColParis,nextRowParis,nextColParis,field);
                        parisCoordinates = givePositionsCoordinates('P',field);
                        currentRowParis=parisCoordinates[0];
                        currentColParis=parisCoordinates[1];
                        if(Arrays.equals(enemyCoordinates, parisCoordinates)){
                            energy= fight(energy);
                        } else {
                            energy = decreasesEnergyByMoving(energy);
                        }
                    }else{
                        energy = decreasesEnergyByMoving(energy);
                    }
                    break;
                case "right":
                    nextColParis = currentColParis + 1;
                    nextRowParis = currentRowParis;
                    if (isInField(nextRowParis, nextColParis, field)){
                        move(currentRowParis,currentColParis,nextRowParis,nextColParis,field);
                        parisCoordinates = givePositionsCoordinates('P',field);
                        currentRowParis=parisCoordinates[0];
                        currentColParis=parisCoordinates[1];
                        if(Arrays.equals(enemyCoordinates, parisCoordinates)){
                            energy= fight(energy);
                        } else {
                            energy = decreasesEnergyByMoving(energy);
                        }
                    }else{
                        energy=decreasesEnergyByMoving(energy);
                    }
                    break;
            }
        }
        printResult(currentRowParis, currentColParis, helenRow, helenCol, energy);
        if(0<energy){
            parisDisappear(field,parisCoordinates);
        } else {
            parisDied(field,parisCoordinates);
        }
        printMatrix(field);

    }

    private static int[] givePositionsCoordinates(char ch, char[][] array) {
        int[] coordinates = new int[2];
        for (int row = 0; row < array.length; row++) {
            for (int col = 0; col < array[row].length; col++) {
                char current = array[row][col];
                if (current == ch) {
                    coordinates[0] = row;
                    coordinates[1] = col;
                }
            }
        }
        return coordinates;
    }
    private static boolean isInField(int row, int col, char[][] field){
        if(0<=row && row<field.length && 0<=col && col<field.length){
            return true;
        } else {
            return false;
        }
    }
    private static char[][] move(int currentRow, int currentCol, int nextRow, int nextCol, char[][] field){
        field[currentRow][currentCol] = '-';
        field[nextRow][nextCol] = 'P';
        return field;
    }
    private static int fight(int energy){
        energy = decreasesEnergyByMoving(energy);
        return energy-=2;
    }
    private static int decreasesEnergyByMoving(int energy){
        return energy-=1;
    }
    private static void printResult(int currentRowParis, int currentColParis, int helenRow, int helenCol, int energy){
        if(currentRowParis==helenRow && currentColParis==helenCol){
            System.out.print("Paris has successfully abducted Helen! ");
            System.out.printf("Energy left: %d%n", energy);
        } else {
            System.out.printf("Paris died at %d;%d.%n", currentRowParis, currentColParis);
        }
    }
    private static void printMatrix(char[][] matrix){
        for (char[] chars : matrix) {
            for (char aChar : chars) {
                System.out.print(aChar);
            }
            System.out.println();
        }
    }
    private static char[][] markEnemyPositionInField(char[][] matrix, int enemyRow, int enemyCol){
        if(isInField(enemyRow,enemyCol,matrix)){
            matrix[enemyRow][enemyCol] = 'S';
        }
        return matrix;
    }
    private static char[][] parisDisappear(char[][] matrix, int[] coordinates){
        matrix[coordinates[0]][coordinates[1]] = '-';
        return matrix;
    }
    private static char[][] parisDied(char[][] matrix, int[] coordinates){
        matrix[coordinates[0]][coordinates[1]] = 'X';
        return matrix;
    }
}
