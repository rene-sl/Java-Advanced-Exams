package spaceshipcrafting;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] liquidArr = Arrays.stream(scanner.nextLine().split(" "))
                .mapToInt(Integer::parseInt).toArray();
        int[] itemsArr = Arrays.stream(scanner.nextLine().split(" "))
                .mapToInt(Integer::parseInt).toArray();

        ArrayDeque<Integer> liquids = ParseQueue(liquidArr);
        ArrayDeque<Integer> items = ParseStack(itemsArr);
        TreeMap<String, Integer> advanceMaterials = new TreeMap<>();
        advanceMaterials.put("Glass", 0);
        advanceMaterials.put("Aluminium", 0);
        advanceMaterials.put("Lithium", 0);
        advanceMaterials.put("Carbon fiber", 0);



        while (!(items.isEmpty() || liquids.isEmpty())){
            int currentLiquids = liquids.getFirst();
            Integer currentItem = 0;
            try {
              currentItem = items.peek();
            } catch (NullPointerException e){
                System.out.print("NullPointerException caught");
            }
            int sumMaterials = 0;
            if (currentItem!=null) {
                sumMaterials = currentItem + currentLiquids;
            }
            String material ="";
            boolean flag = false;

            switch (sumMaterials){
                case 25:
                    material = "Glass";
                    flag = true;
                    break;
                case 50:
                    material = "Aluminium";
                    flag = true;
                    break;
                case 75:
                    material = "Lithium";
                    flag = true;
                    break;
                case 100:
                    material = "Carbon fiber";
                    flag = true;
                    break;
            }
            if(!material.equals("")){
                int current = advanceMaterials.get(material) + 1;
                advanceMaterials.put(material, current);
            }

            if (flag){
                liquids.poll();
                items.pop();
            } else {
                liquids.remove();
                int current = items.pop() + 3;
                items.push(current);
            }
        }


        if(isShipBuild(advanceMaterials)){
            System.out.printf("Wohoo! You succeeded in building the spaceship!%n");
        } else {
            System.out.printf("Ugh, what a pity! You didn't have enough materials to build the spaceship.%n");
        }
        if (liquids.isEmpty()){
            System.out.printf("Liquids left: none%n");
        } else {
            System.out.printf("Liquids left: %n");
            printArrayDeck(liquids);
            System.out.println();
        }
        if (items.isEmpty()){
            System.out.printf("Physical items left: none%n");
        } else {
            System.out.print("Physical items left: ");
            printArrayDeck(items);
            System.out.println();
        }

        printMap(advanceMaterials);

    }

    private static ArrayDeque<Integer> ParseStack(int[] itemsArr) {
        ArrayDeque<Integer> items = new ArrayDeque<>();
        for (int i : itemsArr) {
            items.push(i);
        }
        return items;
    }

    private static ArrayDeque<Integer> ParseQueue(int[] liquidArr) {
        ArrayDeque<Integer> queue = new ArrayDeque<>();
        for (int i : liquidArr) {
            queue.add(i);
        }
        return queue;
    }

    private static void printArrayDeck (ArrayDeque<Integer> arrayDeque){
        while (1<arrayDeque.size()){
            System.out.print(arrayDeque.poll());
            System.out.print(", ");
        }
        System.out.printf("%d",arrayDeque.peek());
    }

    private static void printMap(TreeMap<String,Integer> map){
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.printf("%s: %d%n", entry.getKey(), entry.getValue());
        }
    }
    private static  boolean isShipBuild(TreeMap<String, Integer> map){
        int counter = 0;
        for (Integer value : map.values()) {
            if(value!=0){
                counter++;
            }
        }
        return counter == 4;
    }
}
