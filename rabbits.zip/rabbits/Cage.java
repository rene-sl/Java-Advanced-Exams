package rabbits;

import java.util.ArrayList;
import java.util.List;


public class Cage {
    private String name;
    private int capacity;
    private List<Rabbit> data;


    public Cage(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }


    public String getName() {
        return this.name;
    }

    public int getCapacity() {
        return this.capacity;
    }

    public void add(Rabbit rabbit) {
        if (data.size()<getCapacity()){
            data.add(rabbit);
        }
    }

    public boolean removeRabbit(String name){
        boolean removed = false;
        if (data.contains(name)){
            data.remove(name);
            removed = true;
        }
           return removed;
    }

    public void removeSpecies(String species){
        for (Rabbit datum : data) {
            if (datum.getSpecies().equals(species)){
                removeRabbit(datum.getName());
            }
        }
    }

    public Rabbit sellRabbit(String name){
        Rabbit returnRabit = null;
        for (Rabbit rabbit : data) {
            if(rabbit.getName().equals(name)){
                rabbit.setAvailable();
                returnRabit = rabbit;
                break;
            }
        }
        return returnRabit;
    }

    public List<Rabbit> sellRabbitBySpecies(String species){
        List<Rabbit> soldRabbit = new ArrayList<>();
        for (Rabbit rabbit : data) {
            if (rabbit.getSpecies().equals(species)){
                soldRabbit.add(rabbit);
                sellRabbit(rabbit.getName());
            }
        }
        return soldRabbit;
    }

    public int count(){
      return   data.size();
    }

    public String report(){
        String format= String.format("Rabbits available at %s:%n",this.name);
        for (Rabbit rabbit : data) {
           format+= rabbit.toString();
        }
        return format.trim();
    }



}
