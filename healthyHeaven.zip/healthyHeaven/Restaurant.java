package healthyHeaven;

import java.util.ArrayList;
import java.util.List;

public class Restaurant {
    private String name;
    private List<Salad> data;

    public Restaurant(String name) {
        this.name = name;
        this.data = new ArrayList<>();
    }

    public void add (Salad salad){
        this.data.add(salad);
    }

    public boolean buy(String name){
        boolean isSaladInMenu = false;
        for (Salad salads : data) {
            if(salads.getName().equalsIgnoreCase(name)){
                data.remove(salads);
                isSaladInMenu= true;
            } else {
                isSaladInMenu= false;
            }
        }
        return isSaladInMenu;
    }

    public Salad getHealthiestSalad(){
        int min = Integer.MAX_VALUE;
        Salad healthiestSalad = null;
        for (Salad salad : data) {
            int current = salad.getTotalCalories();
            if (current<min){
                min=current;
                healthiestSalad = salad;
            }
        }
        return healthiestSalad;
    }

    public String generateMenu(){
        String format = String.format("%s have %d salads:%n", this.name, this.data.size());
        for (Salad datum : data) {
           format+= datum.toString();
        }
      return format.trim();

    }
}
