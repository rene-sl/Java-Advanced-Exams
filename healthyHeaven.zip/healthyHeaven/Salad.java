package healthyHeaven;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Salad {
 private String name;
 private HashMap<String, List<Vegetable>> products;


    public Salad(String name) {
        this.name = name;
        this.products = new HashMap<>();
    }

    public void add(Vegetable product){
        this.products.putIfAbsent(this.name, new ArrayList<>());
        this.products.get(this.name).add(product);
    }

    public String getName() {
        return this.name;
    }

    public int getTotalCalories() {
        int sumCalories = 0;
        for (List<Vegetable> value : products.values()) {
            for (Vegetable vegetable : value) {
               sumCalories+= vegetable.getCalories();
            }

        }

        return sumCalories;
    }

    public int getProductCount(){
        int productCount=0;
        for (List<Vegetable> value : products.values()) {
           productCount=value.size();
        }
       return productCount ;
    }

    @Override
    public String toString (){
        String format =  String.format("* Salad %s is %d calories and have %d products:%n",
                this.name, this.getTotalCalories(), this.getProductCount());
        for (List<Vegetable> vegetableList : products.values()) {
            for (Vegetable vegetable : vegetableList) {
               format+= vegetable.toString();

            }
        }
        return format;
        }

}
