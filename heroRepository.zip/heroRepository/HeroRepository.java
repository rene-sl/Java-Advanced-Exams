package heroRepository;

import java.util.ArrayList;
import java.util.List;

public class HeroRepository {
    private List<Hero> data;

    public HeroRepository(){
        data = new ArrayList<>();
    }
    public void add(Hero hero){
        data.add(hero);
    }
    public void remove(String name){
        for (Hero datum : data) {
            if(datum.getName().matches(name)){
                data.remove(datum);
            }
        }
    }
    public Hero getHeroWithHighestStrength(){
        int maxStrenhgt = Integer.MIN_VALUE;
        Hero hero = null;
        for (Hero datum : data) {
           if(maxStrenhgt<datum.getItem().getStrength()) {
               maxStrenhgt = datum.getItem().getStrength();
               hero = datum;
           }
        }
        return hero;
    }
    public Hero getHeroWithHighestAgility(){
        int maxAgility = Integer.MIN_VALUE;
        Hero hero = null;
        for (Hero datum : data) {
            if(maxAgility<datum.getItem().getAgility()) {
                maxAgility = datum.getItem().getAgility();
                hero = datum;
            }
        }
        return hero;
    }
    public Hero getHeroWithHighestIntelligence(){
        int maxIntelligence = Integer.MIN_VALUE;
        Hero hero = null;
        for (Hero datum : data) {
            if(maxIntelligence<datum.getItem().getIntelligence()) {
                maxIntelligence = datum.getItem().getIntelligence();
                hero = datum;
            }
        }
        return hero;
    }
    public int getCount(){
        return data.size();
    }
    @Override
    public String toString(){
        String result = "";
        for (Hero hero : data) {
           result+= hero.toString();
        }
        return result.trim();
    }
}
