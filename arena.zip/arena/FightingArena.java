package arena;

import java.util.ArrayList;
import java.util.List;

public class FightingArena {
    private List<Gladiator> gladiators;
    private String name;

    public FightingArena(String name) {
        this.gladiators = new ArrayList<>();
        this.name = name;
    }

    public void add(Gladiator gladiator) {
        this.gladiators.add(gladiator);
    }

    public void remove(String name) {
        for (Gladiator gladiator : gladiators) {
            if (gladiator.getName().equals(name)) {
                gladiators.remove(gladiator);
            }
        }
    }

    public Gladiator getGladiatorWithHighestStatPower() {
     Gladiator gladiatorWithHighestStat = null;
     int max = Integer.MIN_VALUE;
        for (Gladiator gladiator : gladiators) {
            if (max < gladiator.getStatPower()){
                max = gladiator.getStatPower();
                gladiatorWithHighestStat = gladiator;
            }
        }
        return gladiatorWithHighestStat;
    }
    public Gladiator getGladiatorWithHighestWeaponPower(){
        Gladiator gladiatorWithHighestWeapon = null;
        int max = Integer.MIN_VALUE;
        for (Gladiator gladiator : gladiators) {
            if (max < gladiator.getWeaponPower()){
                max = gladiator.getWeaponPower();
                gladiatorWithHighestWeapon = gladiator;
            }
        }
        return gladiatorWithHighestWeapon;
    }
    public Gladiator getGladiatorWithHighestTotalPower(){
        Gladiator gladiatorHighestTotal = null;
        int max = Integer.MIN_VALUE;
        for (Gladiator gladiator : gladiators) {
            if (max < gladiator.getTotalPower()){
                max =gladiator.getTotalPower();
                gladiatorHighestTotal = gladiator;
            }
        }
        return gladiatorHighestTotal;
    }
    public int getCount(){
        return gladiators.size();
    }
    @Override
    public String toString(){
        return String.format("%s – %d gladiators are participating.", this.name, this.getCount());
    }
}
