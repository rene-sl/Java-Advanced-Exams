package spaceStationRecruitment;

import java.util.ArrayList;
import java.util.List;

public class SpaceStation {
    private String name;
    private int capacity;
    private List<Astronaut> data;


    public SpaceStation(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public int getCapacity() {
        return capacity;
    }

    public int getCount() {
        return this.data.size();
    }

    public void add(Astronaut astronaut) {
        if (data.size() < this.getCapacity()) {
            data.add(astronaut);
        }
    }

    public boolean remove (String name){
        boolean isRemoved = false;
        for (Astronaut astronaut : data) {
            if(astronaut.getName().equals(name)){
                data.remove(astronaut);
                isRemoved = true;
            }
        }
        return isRemoved;
    }

    public Astronaut getOldestAstronaut(){
        Astronaut oldestAstronaut = null;
        int maxAge = Integer.MIN_VALUE;
        for (Astronaut datum : data) {
            if (maxAge < datum.getAge()){
                maxAge=datum.getAge();
                oldestAstronaut = datum;
            }
        }
        return oldestAstronaut;
    }

    public Astronaut getAstronaut(String name){
        return this.data.stream().filter(e-> e.getName().equals(name)).findFirst().orElse(null);

        }


    public String report(){
        String format = String.format("Astronauts working at Space Station %s:%n", this.getName());
        for (Astronaut datum : data) {
            format+= datum.toString();
        }

        return format.trim();
    }
}

