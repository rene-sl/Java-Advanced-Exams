package christmas;

import java.util.ArrayList;
import java.util.List;

public class Bag {
    private String color;
    private int capacity;
    private List<Present> data;

    public Bag(String color, int capacity) {
        this.color = color;
        this.capacity = capacity;
        this.data = new ArrayList<>();
    }

    public String getColor() {
        return this.color;
    }

    public int getCapacity() {
        return this.capacity;
    }
    public int count(){
        return data.size();
    }
    public void add(Present present){
        if(this.count() < this.getCapacity()){
            data.add(present);
        }
    }
    public boolean remove(String name){
        boolean isDeleted = false;
        for (Present present : data) {
            if(present.getName().equals(name)){
                data.remove(present);
                isDeleted = true;
            }
        }
        return isDeleted;
    }
    public Present heaviestPresent(){
        Present heaviestPresent = null;
        double weight = Double.MIN_VALUE;
        for (Present present : data) {
            if(weight < present.getWeight()){
                heaviestPresent=present;
                weight=present.getWeight();
            }
        }

        return heaviestPresent;
    }
    public Present getPresent(String name){
        Present present = null;
        for (Present datum : data) {
            if(datum.getName().equals(name)){
                present = datum;
            }
        }
        return present;
    }

    public String report(){
        String result = String.format("%s bag contains:%n",this.getColor());
        for (Present present : data) {
           result+= present.toString();
        }
        return result.trim();
    }
}
