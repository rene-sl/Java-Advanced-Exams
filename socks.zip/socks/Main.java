package socks;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int [] data = Arrays.stream(scanner.nextLine().split("\\s+"))
                .mapToInt(Integer::parseInt).toArray();
        ArrayDeque<Integer> stackLeftSocks = createStack(data);
        data = Arrays.stream(scanner.nextLine().split("\\s+"))
                .mapToInt(Integer::parseInt).toArray();
        ArrayDeque<Integer> queueRightSocks = createQueue(data);
        ArrayList<Integer> socksPairs = new ArrayList<>();

        while (!queueRightSocks.isEmpty() && !stackLeftSocks.isEmpty()){
            int leftSock = stackLeftSocks.peek();
            int rightSock = queueRightSocks.getFirst();
            if(leftSock==rightSock){
                queueRightSocks.poll();
               int newLeftElement = stackLeftSocks.pop() + 1;
               stackLeftSocks.push(newLeftElement);
            } else if(rightSock<leftSock){
                int sum = createAPair(leftSock, rightSock);
                addPairToCollection(socksPairs, sum);
                queueRightSocks.poll();
                stackLeftSocks.pop();
            } else if(leftSock<rightSock){
                stackLeftSocks.pop();
            }
        }
        System.out.println(biggerSocksPair(socksPairs));
         printList(socksPairs);

    }



    public static ArrayDeque<Integer> createStack(int[] array){
        ArrayDeque<Integer>stack = new ArrayDeque<>();
        for (int i : array) {
            stack.push(i);
        }
        return stack;
    }

    public static ArrayDeque<Integer> createQueue(int[] array){
        ArrayDeque<Integer>queue = new ArrayDeque<>();
        for (int i : array) {
            queue.add(i);
        }
        return queue;
    }

    public static int createAPair(int left, int right){
        return left+right;
    }
    private static void addPairToCollection(ArrayList<Integer> socksPairs, int sum) {
        socksPairs.add(sum);
    }
    private static void printList(List<Integer>list){
        for (Integer integer : list) {
            System.out.print(integer+" ");
        }
    }

    private static int biggerSocksPair(List<Integer>list){
        int biggerSocksPair = Integer.MIN_VALUE;
        for (Integer integer : list) {
            if(biggerSocksPair<integer){
                biggerSocksPair=integer;
            }
        }
        return biggerSocksPair;
    }
}
