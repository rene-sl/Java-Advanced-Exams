package thegarden;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int size = Integer.parseInt(scanner.nextLine());
        char[][] field = putVegetablesInside(scanner, size);
        int [] counterHarvest = new int[3];
        int  harmedCounter = 0;


        String input = scanner.nextLine();
        while (!input.equals("End of Harvest")) {
            String[] commands = input.split(" ");
            String command = commands[0];

            if (command.equals("Harvest")) {
                int rowIndex = Integer.parseInt(commands[1]);
                int colIndex = Integer.parseInt(commands[2]);
                if (isInField(rowIndex,colIndex,field)) {
                    char symbol = field[rowIndex][colIndex];
                    counterHarvestVegetables(symbol,counterHarvest);
                    field = harvestVegetables(rowIndex, colIndex, field);

                }


            }else if (command.equals("Mole")) {
                int rowIndex = Integer.parseInt(commands[1]);
                int colIndex = Integer.parseInt(commands[2]);
                String direction = commands[3];

                switch (direction) {
                    case "up":
                        field = upMole(rowIndex,colIndex,field);
                        break;
                    case "down":
                        field = downMole (rowIndex,colIndex,field);
                        break;
                    case "left":
                        field = leftMole(rowIndex, colIndex, field);
                        break;
                    case "right":
                        field = rightMole(rowIndex,colIndex,field);
                        break;
                }
            }


            input = scanner.nextLine();
        }
        printLeftVegetables(field);
        printCounterHarvest(counterHarvest);
        printHarmedCounter(harmedCounter);

    }


    private static char[][] downMole(int row, int col, char[][] matrix) {
        while (isInField(row,col,matrix)){
            matrix[row][col]=' ';
            row+=2;

        }
        return matrix;

    }

    private static char[][] upMole(int row, int col, char[][] matrix) {
        while (isInField(row,col,matrix)){
            matrix[row][col]=' ';
            row-=2;
        }
        return matrix;
    }

    private static char[][] rightMole(int row, int col, char[][] matrix) {
        while (isInField(row,col,matrix)) {
                matrix[row][col] = ' ';
            col += 2;
        }
        return matrix;
    }

    private static char[][] leftMole(int row, int col, char[][] matrix) {
        while (0 <= col) {
            if (isInField(row, col, matrix)) {
                matrix[row][col] = ' ';
            } else {
                break;
            }
            col -= 2;
        }
        return matrix;
    }

    private static char[][] harvestVegetables(int row, int col, char[][] matrix) {
            matrix[row][col]= ' ';
        return matrix;
    }

    private static char[][] putVegetablesInside(Scanner scanner, int size) {
        char[][] field = new char[size][];
        for (int i = 0; i < field.length; i++) {
            String[] row = scanner.nextLine().split(" ");
            char[] rowChars = new char[row.length];
            for (int j = 0; j < row.length; j++) {
                rowChars[j] = row[j].charAt(0);
            }
            field[i] = rowChars;
        }
        return field;
    }

    private static void printLeftVegetables(char[][] field) {
        for (char[] chars : field) {
            for (char aChar : chars) {
                System.out.print(aChar + " ");
            }
            System.out.println();
        }
    }

    private static boolean isInField(int row, int col, char[][] field) {
        boolean isInField = false;
        if(0<=row &&row<field.length && col<field[row].length){
            isInField = true;
        }
        return isInField;
    }





    private static int[] counterHarvestVegetables(char symbol, int[]count) {
        if(symbol=='C'){
            count[0]=count[0]+1;
        } else if( symbol=='P'){
            count[1]=count[1]+1;
        }else if(symbol=='L'){
            count[2]=count[2]+1;
        }
        return count;
    }

    private static int counterHarmedVegetables(int count) {
        count+=1;
        return count;
    }

    private  static void printCounterHarvest(int[]count){
        System.out.printf("Carrots: %d%n" +
                "Potatoes: %d%n" +
                "Lettuce: %d%n", count[0], count[1], count[2]);
    }
    private static void printHarmedCounter(int counterHarmed) {
        System.out.printf("Harmed vegetables: %d",counterHarmed);
    }
}
