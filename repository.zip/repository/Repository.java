package repository;

import java.util.LinkedHashMap;
import java.util.Map;

public class Repository {
    private Map<Integer, Person> data;
    private int id = -1;

    public Repository() {
        this.data = new LinkedHashMap<>();
    }

    public void add(Person person) {
        data.put(++id, person);
    }

    public Person get(int id) {
        Person person = null;
        for (Map.Entry<Integer, Person> entry : data.entrySet()) {
            if (entry.getKey() == id) {
                person= entry.getValue();
            }
        }
        return person;
    }


    public boolean update(int id, Person newPerson){
        if(data.containsKey(id)){
            data.put(id,newPerson);
            return true;
        } else {
            return false;
        }
    }
    public boolean delete(int id){
        if(data.containsKey(id)){
            Person personForRemoving = data.get(id);
            data.remove(id,personForRemoving);
            return true;
        }else {
            return false;
        }
    }
    public int getCount(){
        return data.size();
    }
}
